var searchData=
[
  ['sender_5fevh_0',['sender_evh',['../namespacesender__evh.html',1,'']]],
  ['state_5fmanager_1',['state_manager',['../namespacestate__manager.html',1,'']]]
];
