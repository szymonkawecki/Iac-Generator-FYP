var searchData=
[
  ['event_5fhub_5fname_0',['EVENT_HUB_NAME',['../namespacefunction.html#a83032b7c41b89fa852cd8e66015f02ef',1,'function']]],
  ['event_5fhub_5fnamespace_1',['EVENT_HUB_NAMESPACE',['../namespacefunction.html#a110153d6d1da9f8d4f3ae1e38993676c',1,'function']]]
];
