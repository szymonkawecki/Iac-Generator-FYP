var searchData=
[
  ['read_5flast_5fstate_0',['read_last_state',['../namespacestate__manager.html#a76fb8785ea4892153c521074c4e78703',1,'state_manager']]]
];
