var searchData=
[
  ['update_5flast_5fstate_0',['update_last_state',['../namespacestate__manager.html#acc7e47fb347d3bf3603d835e93d7c82b',1,'state_manager']]]
];
