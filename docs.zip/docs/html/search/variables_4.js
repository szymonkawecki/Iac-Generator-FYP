var searchData=
[
  ['resource_5fgroup_5fregex_0',['RESOURCE_GROUP_REGEX',['../namespacehome.html#a8ccc33e1363a0cfb488fddcecf5dece8',1,'home']]],
  ['row_5fkey_1',['ROW_KEY',['../namespacestate__manager.html#a73f47d1aad4213a7ecb7d4aaa330ebc1',1,'state_manager']]]
];
